import SwiftUI
import Security
import Combine

@MainActor final class LicenseAuth: ObservableObject {
    @Published var isUnlocked = false
    @Published var isBusy = false
    @Published var message: String?
    // Set the ISAIX_API_BASE_URL Info.plist value in the build workflow after deploying the API.
    private var apiBaseURL: URL {
        let value = Bundle.main.object(forInfoDictionaryKey: "ISAIX_API_BASE_URL") as? String
        return URL(string: value ?? "https://YOUR-DOMAIN.example")!
    }
    private let keyTag = "com.isaix.store.license"
    private let deviceTag = "com.isaix.store.device"

    init() { Task { await validateSavedKey() } }
    func activate(_ rawKey: String) async {
        let key = rawKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { message = "Enter your access key."; return }
        isBusy = true; defer { isBusy = false }
        do {
            let result = try await request(path: "/v1/activate", body: ["key": key, "device_id": deviceID()])
            guard result["valid"] as? Bool == true else { message = result["detail"] as? String ?? "Activation failed."; return }
            save(key, tag: keyTag); isUnlocked = true; message = nil
        } catch { message = error.localizedDescription }
    }
    func validateSavedKey() async {
        guard let key = read(tag: keyTag) else { return }
        do { let result = try await request(path: "/v1/validate", body: ["key": key, "device_id": deviceID()]); isUnlocked = result["valid"] as? Bool == true; if !isUnlocked { message = "This license is no longer valid."; delete(tag: keyTag) } }
        catch { message = "Cannot reach the license server. Connect to the internet and try again." }
    }
    private func request(path: String, body: [String: String]) async throws -> [String: Any] {
        var req = URLRequest(url: apiBaseURL.appendingPathComponent(path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))))
        req.httpMethod = "POST"; req.setValue("application/json", forHTTPHeaderField: "Content-Type"); req.httpBody = try JSONSerialization.data(withJSONObject: body); req.timeoutInterval = 15
        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw URLError(.badServerResponse) }
        return (try JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
    }
    private func deviceID() -> String {
        if let old = read(tag: deviceTag) { return old }
        let value = UUID().uuidString.lowercased(); save(value, tag: deviceTag); return value
    }
    private func save(_ value: String, tag: String) { let data = Data(value.utf8); delete(tag: tag); SecItemAdd([kSecClass as String:kSecClassGenericPassword, kSecAttrAccount as String:tag, kSecValueData as String:data, kSecAttrAccessible as String:kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly] as CFDictionary, nil) }
    private func read(tag: String) -> String? { var result: CFTypeRef?; let status = SecItemCopyMatching([kSecClass as String:kSecClassGenericPassword, kSecAttrAccount as String:tag, kSecReturnData as String:true, kSecMatchLimit as String:kSecMatchLimitOne] as CFDictionary, &result); guard status == errSecSuccess, let data = result as? Data else { return nil }; return String(data: data, encoding: .utf8) }
    private func delete(tag: String) { SecItemDelete([kSecClass as String:kSecClassGenericPassword, kSecAttrAccount as String:tag] as CFDictionary) }
}

struct LicenseGateView: View {
    @EnvironmentObject private var auth: LicenseAuth
    @State private var key = ""
    var body: some View {
        VStack(spacing: 22) {
            Spacer()
            Image(systemName: "lock.shield.fill").font(.system(size: 54)).foregroundStyle(.cyan)
            Text("Isaix Store").font(.largeTitle.bold())
            Text("Enter your license key to activate this device.").foregroundStyle(.secondary).multilineTextAlignment(.center)
            TextField("License key", text: $key).textInputAutocapitalization(.characters).autocorrectionDisabled().padding().background(.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
            if let message = auth.message { Text(message).font(.footnote).foregroundStyle(.orange).multilineTextAlignment(.center) }
            Button { Task { await auth.activate(key) } } label: { if auth.isBusy { ProgressView().tint(.black) } else { Text("Activate") } }.font(.headline).foregroundStyle(.black).frame(maxWidth: .infinity).padding().background(.cyan, in: RoundedRectangle(cornerRadius: 12)).disabled(auth.isBusy)
            Spacer(); Text("One license · One device").font(.caption).foregroundStyle(.secondary)
        }.padding(28).frame(maxWidth: .infinity, maxHeight: .infinity).background(Color(red: 0.035, green: 0.045, blue: 0.07))
    }
}
