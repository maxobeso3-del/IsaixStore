import SwiftUI
import UIKit
import UniformTypeIdentifiers

@main
struct IsaixStoreApp: App {
    @StateObject private var auth = LicenseAuth()
    var body: some Scene {
        WindowGroup {
            Group {
                if auth.isUnlocked { MainShell().environmentObject(auth) }
                else { LicenseGateView().environmentObject(auth) }
            }
            .preferredColorScheme(.dark)
        }
    }
}

struct MainShell: View {
    var body: some View {
        TabView {
            DashboardView().tabItem { Label("Home", systemImage: "square.grid.2x2") }
            GestaltView().tabItem { Label("Gestalt", systemImage: "slider.horizontal.3") }
            FileBrowserView().tabItem { Label("Files", systemImage: "folder") }
            PatchView().tabItem { Label("Patches", systemImage: "shippingbox") }
            ToolsView().tabItem { Label("Tools", systemImage: "wrench.and.screwdriver") }
        }
        .tint(.cyan)
    }
}

struct DashboardView: View {
    @State private var showInfo = false
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("ISAIX STORE").font(.caption.weight(.bold)).tracking(2).foregroundStyle(.cyan)
                        Text("Device workspace").font(.largeTitle.bold())
                        Text("Manage supported device metadata, files, and patch projects.").foregroundStyle(.secondary)
                    }
                    HStack(spacing: 12) {
                        StatusCard(title: "iOS", value: UIDevice.current.systemVersion, symbol: "iphone")
                        StatusCard(title: "Access", value: "Standard", symbol: "lock.shield")
                    }
                    NavigationLink { GestaltView() } label: { FeatureRow(icon: "slider.horizontal.3", title: "MobileGestalt Editor", detail: "Browse capability definitions", tint: .cyan) }
                    NavigationLink { FileBrowserView() } label: { FeatureRow(icon: "folder", title: "File Browser", detail: "Import, organize, and export files", tint: .blue) }
                    NavigationLink { PatchView() } label: { FeatureRow(icon: "shippingbox", title: "Patch Manager", detail: "Create and exchange patch projects", tint: .purple) }
                    NavigationLink { ToolsView() } label: { FeatureRow(icon: "wrench.and.screwdriver", title: "Utilities", detail: "Cleaner, wallpapers, access status", tint: .orange) }
                    Label("Protected system edits and exploit access are not enabled in this starter build.", systemImage: "info.circle.fill")
                        .font(.footnote).foregroundStyle(.secondary).padding().frame(maxWidth: .infinity, alignment: .leading)
                        .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14))
                }.padding()
            }
            .background(Color(red: 0.035, green: 0.045, blue: 0.07))
            .navigationTitle("Isaix Store")
        }
    }
}

struct StatusCard: View {
    let title: String; let value: String; let symbol: String
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Image(systemName: symbol).foregroundStyle(.cyan)
            Text(title).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.headline)
        }.frame(maxWidth: .infinity, alignment: .leading).padding(16)
            .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 16))
    }
}

struct FeatureRow: View {
    let icon: String; let title: String; let detail: String; let tint: Color
    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: icon).font(.title2).foregroundStyle(tint).frame(width: 44, height: 44).background(tint.opacity(0.14), in: RoundedRectangle(cornerRadius: 12))
            VStack(alignment: .leading, spacing: 4) { Text(title).font(.headline).foregroundStyle(.primary); Text(detail).font(.caption).foregroundStyle(.secondary) }
            Spacer(); Image(systemName: "chevron.right").font(.caption.bold()).foregroundStyle(.tertiary)
        }.padding(14).background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16))
    }
}

struct GestaltItem: Identifiable {
    let id: String; let name: String; let group: String; let detail: String
}

struct GestaltView: View {
    @State private var query = ""
    @State private var selectedGroup = "All"
    private let groups = ["All", "Device", "Display", "Features", "Internal"]
    private let items = [
        GestaltItem(id:"ProductType",name:"Product Type",group:"Device",detail:"Reported hardware family identifier"),
        GestaltItem(id:"ProductVersion",name:"Product Version",group:"Device",detail:"Operating system version metadata"),
        GestaltItem(id:"DeviceClass",name:"Device Class",group:"Device",detail:"iPhone, iPad, or other device class"),
        GestaltItem(id:"DeviceName",name:"Device Name",group:"Device",detail:"Reported device model name"),
        GestaltItem(id:"AlwaysOnDisplay",name:"Always-On Display",group:"Display",detail:"Capability catalog entry"),
        GestaltItem(id:"StageManager",name:"Stage Manager",group:"Display",detail:"Multitasking capability catalog entry"),
        GestaltItem(id:"AppleIntelligence",name:"Apple Intelligence",group:"Features",detail:"Feature eligibility catalog entry"),
        GestaltItem(id:"ApplePencil",name:"Apple Pencil",group:"Features",detail:"Accessory capability catalog entry"),
        GestaltItem(id:"BootChime",name:"Boot Chime",group:"Features",detail:"Feature capability catalog entry"),
        GestaltItem(id:"InternalStorage",name:"Internal Storage Flags",group:"Internal",detail:"Internal metadata; editing unavailable")
    ]
    private var filtered: [GestaltItem] { items.filter { (selectedGroup == "All" || $0.group == selectedGroup) && (query.isEmpty || $0.name.localizedCaseInsensitiveContains(query) || $0.id.localizedCaseInsensitiveContains(query)) } }
    var body: some View {
        NavigationStack {
            List {
                Section { Text("This is a reference catalog. Reading or writing protected MobileGestalt values requires supported privileged access and is not implemented here.").font(.footnote).foregroundStyle(.secondary) }
                Section {
                    Picker("Category", selection: $selectedGroup) { ForEach(groups, id: \.self) { Text($0) } }.pickerStyle(.menu)
                    ForEach(filtered) { item in
                        NavigationLink { GestaltDetail(item: item) } label: {
                            VStack(alignment: .leading, spacing: 4) { Text(item.name).font(.body.weight(.medium)); Text(item.id).font(.caption.monospaced()).foregroundStyle(.secondary) }
                        }
                    }
                } header: { Text("Capability catalog") }
            }
            .searchable(text: $query, prompt: "Search capabilities")
            .navigationTitle("MobileGestalt")
        }
    }
}

struct GestaltDetail: View {
    let item: GestaltItem
    var body: some View {
        Form {
            Section("Capability") { LabeledContent("Name", value: item.name); LabeledContent("Key", value: item.id); LabeledContent("Group", value: item.group) }
            Section("Description") { Text(item.detail) }
            Section { Label("Read/write access is unavailable in this build.", systemImage: "lock.fill").foregroundStyle(.secondary) }
        }.navigationTitle(item.name).navigationBarTitleDisplayMode(.inline)
    }
}

struct FileBrowserView: View {
    @State private var files: [URL] = []
    @State private var importing = false
    @State private var showingFolderName = false
    @State private var folderName = ""
    @State private var renameTarget: URL?
    @State private var renameName = ""
    @State private var error: String?

    private var documentsURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    var body: some View {
        NavigationStack {
            List {
                Section("App workspace") {
                    if files.isEmpty {
                        ContentUnavailableView("Workspace is empty", systemImage: "folder", description: Text("Import files or create a folder to get started."))
                    }
                    ForEach(files, id: \.absoluteString) { url in
                        HStack {
                            Image(systemName: (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true ? "folder" : "doc")
                                .foregroundStyle(.cyan)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(url.lastPathComponent).lineLimit(1)
                                Text((try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true ? "FOLDER" : (url.pathExtension.uppercased().isEmpty ? "FILE" : url.pathExtension.uppercased()))
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            if (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) != true {
                                ShareLink(item: url) { Image(systemName: "square.and.arrow.up") }
                            }
                        }
                        .contextMenu {
                            Button("Rename", systemImage: "pencil") { renameTarget = url; renameName = url.lastPathComponent }
                            Button("Duplicate", systemImage: "plus.square.on.square") { duplicate(url) }
                            Button("Delete", systemImage: "trash", role: .destructive) { remove(url) }
                        }
                    }
                }
                Section {
                    Text("The workspace is stored inside Isaix Store. Files outside the app are available only after you select them. iOS does not expose other apps' private containers or protected system folders through the standard document picker.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("File Browser")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Menu {
                        Button("Import files", systemImage: "square.and.arrow.down") { importing = true }
                        Button("New folder", systemImage: "folder.badge.plus") { showingFolderName = true }
                    } label: { Image(systemName: "plus") }
                }
            }
            .onAppear(perform: refresh)
            .fileImporter(isPresented: $importing, allowedContentTypes: [.item], allowsMultipleSelection: true, onCompletion: importResult)
            .alert("New folder", isPresented: $showingFolderName) {
                TextField("Folder name", text: $folderName)
                Button("Create") { createFolder() }
                Button("Cancel", role: .cancel) { folderName = "" }
            }
            .alert("Rename item", isPresented: Binding(get: { renameTarget != nil }, set: { if !$0 { renameTarget = nil } })) {
                TextField("New name", text: $renameName)
                Button("Save") { renameItem() }
                Button("Cancel", role: .cancel) { renameTarget = nil }
            }
            .alert("File operation", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(error ?? "") }
        }
    }

    private func refresh() {
        do {
            files = try FileManager.default.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: [.isDirectoryKey, .fileSizeKey], options: [.skipsHiddenFiles]).sorted { $0.lastPathComponent.localizedCaseInsensitiveCompare($1.lastPathComponent) == .orderedAscending }
        } catch { self.error = error.localizedDescription }
    }

    private func importResult(_ result: Result<[URL], Error>) {
        switch result {
        case .success(let urls):
            for url in urls {
                let access = url.startAccessingSecurityScopedResource()
                defer { if access { url.stopAccessingSecurityScopedResource() } }
                let destination = uniqueDestination(for: url.lastPathComponent)
                do { try FileManager.default.copyItem(at: url, to: destination) }
                catch { self.error = error.localizedDescription }
            }
            refresh()
        case .failure(let err): error = err.localizedDescription
        }
    }

    private func uniqueDestination(for name: String) -> URL {
        var candidate = documentsURL.appendingPathComponent(name)
        if !FileManager.default.fileExists(atPath: candidate.path) { return candidate }
        let base = candidate.deletingPathExtension().lastPathComponent
        let ext = candidate.pathExtension
        var index = 2
        repeat {
            let next = "\(base) \(index)" + (ext.isEmpty ? "" : ".\(ext)")
            candidate = documentsURL.appendingPathComponent(next)
            index += 1
        } while FileManager.default.fileExists(atPath: candidate.path)
        return candidate
    }

    private func createFolder() {
        let clean = folderName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        do { try FileManager.default.createDirectory(at: uniqueDestination(for: clean), withIntermediateDirectories: false); folderName = ""; refresh() }
        catch { self.error = error.localizedDescription }
    }

    private func renameItem() {
        guard let target = renameTarget else { return }
        let clean = renameName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { error = "Enter a valid name."; return }
        let destination = target.deletingLastPathComponent().appendingPathComponent(clean)
        do { try FileManager.default.moveItem(at: target, to: destination); renameTarget = nil; refresh() }
        catch { self.error = error.localizedDescription }
    }

    private func duplicate(_ url: URL) {
        let destination = uniqueDestination(for: url.deletingPathExtension().lastPathComponent + " copy" + (url.pathExtension.isEmpty ? "" : ".\(url.pathExtension)"))
        do { try FileManager.default.copyItem(at: url, to: destination); refresh() }
        catch { self.error = error.localizedDescription }
    }

    private func remove(_ url: URL) {
        do { try FileManager.default.removeItem(at: url); refresh() }
        catch { self.error = error.localizedDescription }
    }
}

struct PatchProject: Codable, Identifiable {
    var id = UUID(); var name: String; var bundleID: String; var notes: String
}
struct PatchView: View {
    @AppStorage("isaix.patchProjects.v1") private var savedProjects = "[]"
    @State private var projects: [PatchProject] = []
    @State private var showingCreate = false
    @State private var importing = false
    @State private var name = ""
    @State private var bundle = ""
    @State private var notes = ""
    @State private var alert: String?

    var body: some View {
        NavigationStack {
            List {
                if projects.isEmpty {
                    ContentUnavailableView("No patch projects", systemImage: "shippingbox", description: Text("Create a project or import a .3105 JSON package."))
                }
                ForEach(projects) { project in
                    VStack(alignment: .leading, spacing: 7) {
                        HStack {
                            Text(project.name).font(.headline)
                            Spacer()
                            ShareLink(item: encoded(project), preview: SharePreview(project.name + ".3105")) {
                                Image(systemName: "square.and.arrow.up")
                            }
                        }
                        Text(project.bundleID.isEmpty ? "No bundle identifier" : project.bundleID)
                            .font(.caption.monospaced()).foregroundStyle(.secondary)
                        if !project.notes.isEmpty { Text(project.notes).font(.footnote) }
                    }
                    .padding(.vertical, 4)
                }
                .onDelete { offsets in projects.remove(atOffsets: offsets); persist() }
                Section {
                    Text("Projects are portable JSON descriptions. Applying patches to protected system or other-app data is not implemented in this build.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Patch Manager")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { EditButton() }
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button { importing = true } label: { Image(systemName: "square.and.arrow.down") }
                    Button { showingCreate = true } label: { Image(systemName: "plus") }
                }
            }
            .sheet(isPresented: $showingCreate) {
                NavigationStack {
                    Form {
                        TextField("Project name", text: $name)
                        TextField("Target bundle ID", text: $bundle)
                            .textInputAutocapitalization(.never).autocorrectionDisabled()
                        TextField("Notes", text: $notes, axis: .vertical)
                    }
                    .navigationTitle("New Patch Project")
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) { Button("Cancel") { showingCreate = false } }
                        ToolbarItem(placement: .confirmationAction) {
                            Button("Create") {
                                projects.append(PatchProject(name: name.isEmpty ? "Untitled Patch" : name, bundleID: bundle, notes: notes))
                                name = ""; bundle = ""; notes = ""; showingCreate = false; persist()
                            }
                        }
                    }
                }
            }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.json, .data], allowsMultipleSelection: true) { result in
                switch result {
                case .success(let urls):
                    for url in urls {
                        let access = url.startAccessingSecurityScopedResource()
                        defer { if access { url.stopAccessingSecurityScopedResource() } }
                        do {
                            let data = try Data(contentsOf: url)
                            let decoder = JSONDecoder()
                            if let many = try? decoder.decode([PatchProject].self, from: data) { projects.append(contentsOf: many) }
                            else { projects.append(try decoder.decode(PatchProject.self, from: data)) }
                        } catch { alert = "Could not import \(url.lastPathComponent): \(error.localizedDescription)" }
                    }
                    persist()
                case .failure(let error): alert = error.localizedDescription
                }
            }
            .onAppear(perform: restore)
            .alert("Patch Manager", isPresented: Binding(get: { alert != nil }, set: { if !$0 { alert = nil } })) {
                Button("OK", role: .cancel) {}
            } message: { Text(alert ?? "") }
        }
    }

    private func encoded(_ project: PatchProject) -> Data { (try? JSONEncoder().encode(project)) ?? Data() }
    private func persist() { if let data = try? JSONEncoder().encode(projects), let value = String(data: data, encoding: .utf8) { savedProjects = value } }
    private func restore() { guard let data = savedProjects.data(using: .utf8), let decoded = try? JSONDecoder().decode([PatchProject].self, from: data) else { return }; projects = decoded }
}

struct ToolsView: View {
    @State private var wallpaperFiles: [URL] = []
    @State private var importWallpaper = false
    @State private var showCleanerInfo = false
    var body: some View {
        NavigationStack {
            List {
                Section("Utilities") {
                    NavigationLink { CleanerView() } label: { Label("Cleaner", systemImage: "sparkles") }
                    NavigationLink { WallpaperView() } label: { Label("Wallpaper Lab", systemImage: "photo") }
                    NavigationLink { ExploitStatusView() } label: { Label("Kernel / Sandbox Access", systemImage: "lock.shield") }
                }
                Section("About") { LabeledContent("Version", value: "1.2.0 (rebuild)"); LabeledContent("Compatibility target", value: "iOS 17+") }
            }.navigationTitle("Tools")
        }
    }
}

struct CleanerView: View {
    @State private var bytes: Int64 = 0
    @State private var message = "Scan app-owned temporary files only."
    var body: some View {
        Form {
            Section("App temporary storage") { Text(message); Button("Scan temporary files") { bytes = tempSize(); message = "Found \(ByteCountFormatter.string(fromByteCount: bytes, countStyle: .file)) in this app's temporary folder." }; Button("Clear temporary files", role: .destructive) { clearTemp(); bytes = 0; message = "App temporary files cleared." } }
            Section { Text("This cleaner does not scan or delete other apps' caches or system files.").font(.footnote).foregroundStyle(.secondary) }
        }.navigationTitle("Cleaner")
    }
    private func tempSize() -> Int64 { let root = FileManager.default.temporaryDirectory; let e = FileManager.default.enumerator(at: root, includingPropertiesForKeys: [.fileSizeKey]); var total: Int64 = 0; while let u = e?.nextObject() as? URL { total += Int64((try? u.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0) }; return total }
    private func clearTemp() { let root = FileManager.default.temporaryDirectory; if let e = FileManager.default.enumerator(at: root, includingPropertiesForKeys: nil) { for case let u as URL in e { try? FileManager.default.removeItem(at: u) } } }
}

struct WallpaperView: View {
    @State private var importing = false
    @State private var names: [String] = []
    var body: some View {
        List { Section { if names.isEmpty { ContentUnavailableView("No wallpaper packages", systemImage: "photo", description: Text("Import image files or .tendies packages.")) }; ForEach(names, id: \.self) { Text($0) } }; Section { Text("This starter stores imported assets; device wallpaper installation and custom package rendering are not implemented.").font(.footnote).foregroundStyle(.secondary) } }
            .navigationTitle("Wallpaper Lab").toolbar { Button("Import") { importing = true } }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.image, .data], allowsMultipleSelection: true) { result in if case .success(let urls) = result { names.append(contentsOf: urls.map(\.lastPathComponent)) } }
    }
}

struct ExploitStatusView: View {
    var body: some View { Form { Section("Access status") { Label("No kernel access", systemImage: "lock.fill").foregroundStyle(.orange); Text("Exploit code from the reference IPA is not included. Kernel exploit compatibility depends on exact iOS build, device model, and security mitigations.").font(.footnote).foregroundStyle(.secondary) }; Section { Text("This app will not claim privileged access unless a separately audited, compatible implementation verifies it.").font(.footnote).foregroundStyle(.secondary) } }.navigationTitle("Access Status") }
}
