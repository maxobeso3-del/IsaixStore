# Isaix Store — iOS 17+ GitHub Actions build

This repository is configured to build an **unsigned IPA** on GitHub's hosted macOS runner. You can do the setup and download from Safari on an iPhone; you do not need to own a Mac.

## Build it from an iPhone

1. Sign in to GitHub in Safari and create a repository named `IsaixStore`. A **public** repository avoids the normal included-minutes restrictions that apply to private-repository macOS runners; remember that public means the source code is visible to everyone. Do not put private keys, certificates, passwords, or admin tokens in this repository.
2. Upload the contents of this folder to the repository's `main` branch. GitHub's website supports uploading files/folders from the browser; if uploading a folder is awkward on iPhone, use the GitHub mobile app or the web editor to add the files while preserving their paths.
3. Open the repository's **Actions** tab, select **Build unsigned Isaix Store IPA**, and tap **Run workflow**. A push to `main` that changes app source or the workflow also starts a build.
4. When the run finishes successfully, open it, scroll to **Artifacts**, and download `IsaixStore-unsigned-IPA`. Extract the ZIP if GitHub downloads the artifact wrapper as a ZIP; inside is `IsaixStore-unsigned.ipa`.
5. Import that IPA into ESign or GBox and sign it with your own valid certificate/provisioning profile. The workflow does not contain or use your signing credentials.

## Configure the license API

The app's key gate calls the FastAPI backend. Until you deploy that backend, activation will not succeed. After deploying it over HTTPS, add a repository **Actions variable** named `ISAIX_API_BASE_URL` with the base URL (for example `https://api.example.com`). Do not put the admin token in the app or repository. Keep `ISAIX_ADMIN_TOKEN` on the server only. Re-run the workflow after setting the variable.

## Build configuration

- Minimum deployment target: iOS 17.0.
- Bundle identifier: `com.isaix.store` (change it to a unique identifier you control if needed).
- Device families: iPhone and iPad.
- No signing credentials are included. The IPA is intentionally unsigned for later signing in ESign/GBox.

## Functional limitations

- The MobileGestalt page is a reference catalog; privileged MobileGestalt writes and exploit integration are not implemented.
- The file browser manages the app's own workspace and files the user explicitly imports. It cannot browse arbitrary app-private containers or protected system folders.
- Patch projects are saved/imported/exported as JSON; privileged patch application is not implemented.
- Cleaner is limited to this app's temporary directory. Wallpaper import is a basic package list, not system wallpaper installation.
- iOS 17 is the deployment minimum. Later versions require real-device testing; iOS 26.6.2 is a requested target, not a verified compatibility claim.

## Troubleshooting

If a build fails, open the failed GitHub Actions run and copy the first red compiler error. Share that error text so the source can be corrected. The source has not been compiled in this environment, so the first hosted build is the compile verification step.
