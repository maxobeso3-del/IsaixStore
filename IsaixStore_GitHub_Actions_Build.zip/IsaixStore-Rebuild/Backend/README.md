# License API
Deploy with HTTPS. Set `ISAIX_ADMIN_TOKEN` to a random secret of at least 32 characters. Never put it in the iOS app. The iOS client uses POST `/v1/activate` and `/v1/validate` with JSON `{ "key": "...", "device_id": "..." }`. Admin endpoints use `X-Admin-Token`.

Create: `POST /admin/licenses` JSON `{ "label": "Customer", "expires_at": null }`
List: `GET /admin/licenses`
Revoke: `POST /admin/licenses/{id}/revoke`
