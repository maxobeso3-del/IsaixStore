import hashlib, os, secrets, sqlite3
from datetime import datetime, timezone
from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

DB = os.getenv('ISAIX_DB', 'isaix.sqlite3')
ADMIN = os.getenv('ISAIX_ADMIN_TOKEN', '')
app = FastAPI(title='Isaix Store License API', version='1.0')

def connect():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    c.execute('''CREATE TABLE IF NOT EXISTS licenses (id INTEGER PRIMARY KEY, key_hash TEXT UNIQUE NOT NULL, label TEXT, device_hash TEXT, active INTEGER NOT NULL DEFAULT 1, expires_at TEXT, created_at TEXT NOT NULL)''')
    return c

def digest(value: str) -> str: return hashlib.sha256(value.encode()).hexdigest()
def admin_check(token):
    if len(ADMIN) < 32 or not secrets.compare_digest(token or '', ADMIN): raise HTTPException(401, 'Unauthorized')
class Activate(BaseModel): key: str; device_id: str
class CreateKey(BaseModel): label: str = ''; expires_at: str | None = None

def license_result(key, device):
    c=connect(); row=c.execute('SELECT * FROM licenses WHERE key_hash=?',(digest(key),)).fetchone()
    if not row or not row['active']: c.close(); return False, 'Invalid or revoked key'
    if row['expires_at'] and row['expires_at'] <= datetime.now(timezone.utc).isoformat(): c.close(); return False, 'License expired'
    dh=digest(device)
    if row['device_hash'] and not secrets.compare_digest(row['device_hash'],dh): c.close(); return False, 'Key is already activated on another device'
    if not row['device_hash']: c.execute('UPDATE licenses SET device_hash=? WHERE id=?',(dh,row['id'])); c.commit()
    c.close(); return True, 'OK'

@app.post('/v1/activate')
def activate(body: Activate):
    ok,msg=license_result(body.key,body.device_id)
    if not ok: raise HTTPException(403,msg)
    return {'valid':True}
@app.post('/v1/validate')
def validate(body: Activate):
    ok,msg=license_result(body.key,body.device_id)
    return {'valid':ok,'detail':msg}
@app.get('/admin/licenses')
def list_keys(x_admin_token: str | None=Header(default=None)):
    admin_check(x_admin_token); c=connect(); rows=[dict(r) for r in c.execute('SELECT id,label,device_hash,active,expires_at,created_at FROM licenses ORDER BY id DESC')]; c.close(); return rows
@app.post('/admin/licenses')
def create_key(body: CreateKey, x_admin_token: str | None=Header(default=None)):
    admin_check(x_admin_token); raw='ISAIX-'+secrets.token_urlsafe(18).upper(); c=connect(); cur=c.execute('INSERT INTO licenses(key_hash,label,expires_at,created_at) VALUES(?,?,?,?)',(digest(raw),body.label,body.expires_at,datetime.now(timezone.utc).isoformat())); c.commit(); ident=cur.lastrowid; c.close(); return {'id':ident,'key':raw}
@app.post('/admin/licenses/{license_id}/revoke')
def revoke(license_id:int,x_admin_token: str | None=Header(default=None)):
    admin_check(x_admin_token); c=connect(); cur=c.execute('UPDATE licenses SET active=0 WHERE id=?',(license_id,)); c.commit(); c.close()
    if not cur.rowcount: raise HTTPException(404,'License not found')
    return {'revoked':True}
@app.get('/admin',response_class=HTMLResponse)
def admin_page():
    return '<h1>Isaix Store License API</h1><p>Use the authenticated /admin/licenses endpoints to create, list, and revoke keys. Keep the admin token private.</p>'
